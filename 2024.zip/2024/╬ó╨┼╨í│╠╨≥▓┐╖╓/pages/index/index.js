Page({
  // 定义跳转函数

  
  data: {
    temp: 0,
    humi:0,
    keytrue:0 // 定义页面数据对象，初始温度值为0
  },
  // 定义事件处理函数，用于发送请求并处理返回数据
  getinfo() {
    // 保存当前函数作用域的引用，以便在回调函数内部访问到this
    var that = this;  
    // 发起网络请求
    wx.request({
      url: "https://iot-api.heclouds.com/thingmodel/query-device-property?product_id=6388g7AIW9&device_name=test",  
      // 请求头部信息
      "header": {
        "authorization": "version=2020-05-29&res=userid%2F383434&et=1778748397&method=sha1&sign=7VO5fmBJva6G0fzgDUgp99Ey8SY%3D"
      },
      method: "GET",  // 请求方法为GET
      // 请求成功的回调函数
      success: function (e) 
      {
        console.log("获取成功", e);  // 打印获取成功的信息和返回的数据对象
        // 更新页面数据，取得返回数据的第2个数据流的第1个数据点的值作为温度值
        that.setData({
          temp: e.data.data[4].value,
          humi: e.data.data[2].value,
          keytrue: e.data.data[3].value
        });
        console.log("temp==", that.data.temp);  // 打印更新后的温度值
      }
    });
  },


  guan:function(){
    wx.request({
      url: 'https://iot-api.heclouds.com/thingmodel/set-device-desired-property',
      header: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'authorization': 'version=2020-05-29&res=userid%2F383434&et=1778748397&method=sha1&sign=7VO5fmBJva6G0fzgDUgp99Ey8SY%3D'
      },
      data: {
        product_id: '6388g7AIW9',
        device_name: 'test',
        params: {"LED": 0}
      },
      method: 'POST',
      success: function(res) {
        console.log("成功",res.data);
      },
      fail: function(err) {
        console.error("失败",err);
      }
    });
   
    wx.navigateTo({
      url: '/pages/anotherPage/anotherPage', // 替换为你要跳转的页面路径
    });
    
  },

 kai:function(){
  wx.request({
    url: 'https://iot-api.heclouds.com/thingmodel/set-device-desired-property',
    header: {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'authorization': 'version=2020-05-29&res=userid%2F383434&et=1778748397&method=sha1&sign=7VO5fmBJva6G0fzgDUgp99Ey8SY%3D'
    },
    data: {
      product_id: '6388g7AIW9',
      device_name: 'test',
      params: {"LED": 1}
    },
    method: 'POST',
    success: function(res) {
      console.log("成功",res.data);
    },
    fail: function(err) {
      console.error("失败",err);
    }
  });
  wx.navigateTo({
    url: '/pages/ture/ture', // 替换为你要跳转的页面路径
  });
},

  onLoad() 
  {
    var that = this;  // 保存当前函数作用域的引用
    setInterval(function()
    {
      that.getinfo();  // 调用getinfo()函数
    },3000);
    
  }
})

