Page({
  data: {
    imageUrl: '../images/对勾1.png' // 图片的路径
  }
});