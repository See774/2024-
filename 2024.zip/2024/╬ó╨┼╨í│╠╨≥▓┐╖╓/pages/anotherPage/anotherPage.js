// pages/anotherPage/anotherPage.js
Page({

})