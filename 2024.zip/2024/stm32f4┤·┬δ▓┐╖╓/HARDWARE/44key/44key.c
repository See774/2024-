#include "44key.h"
#include "sys.h"
#include "delay.h"
/**********************************
44KEY�������ӷ�ʽ�����µ��ϣ���
�У�
PC0
PC1
PC2
PC3
�У�
PC4
PC5
PG6
PG7
***********************************/
u16 key_init_44(void)//4*4������̺���(���ΰ���ģʽ)
{
	static u8 t=1;
	u16 Key_val=0;
	u32 temp=0;
	gpio_init_key4();
	if(t)
	{
		GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
		GPIO_SetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2);
		GPIO_ResetBits(GPIOC,GPIO_Pin_3);
		if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
		{
			delay_ms(10);
			if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
			{
				temp=(GPIOC->IDR&0x37)|(GPIOG->IDR&0xC0);
				switch(temp)
				{
					case 0xE7:Key_val=1;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xD7:Key_val=4;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xB7:Key_val=7;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0x77:Key_val=10;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					default :Key_val=0;
					break;
				}
			}
		}
		GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
		GPIO_SetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3);
		GPIO_ResetBits(GPIOC,GPIO_Pin_2);
		if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
		{
			delay_ms(10);
			if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
			{
				temp=(GPIOC->IDR&0x3B)|(GPIOG->IDR&0xC0);
				switch(temp)
				{
					case 0xEB:Key_val=2;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xDB:Key_val=5;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xBB:Key_val=8;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0x7B:Key_val=11;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					default :Key_val=0;
					break;
				}
			}
		}
		GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
		GPIO_SetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_3|GPIO_Pin_2);
		GPIO_ResetBits(GPIOC,GPIO_Pin_1);
		if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
		{
			delay_ms(10);
			if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
			{
				temp=(GPIOC->IDR&0x3D)|(GPIOG->IDR&0xC0);
				switch(temp)
				{
					case 0xED:Key_val=3;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xDD:Key_val=6;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xBD:Key_val=9;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0x7D:Key_val=12;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					default :Key_val=0;
					break;
				}
			}
		}
		GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
		GPIO_SetBits(GPIOC,GPIO_Pin_3|GPIO_Pin_1|GPIO_Pin_2);
		GPIO_ResetBits(GPIOC,GPIO_Pin_0);
		if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
		{
			delay_ms(10);
			if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0)
			{
				temp=(GPIOC->IDR&0x3E)|(GPIOG->IDR&0xC0);
				switch(temp)
				{
					case 0xEE:Key_val=13;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xDE:Key_val=14;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0xBE:Key_val=15;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					case 0x7E:Key_val=0;while(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))!=0xF0);
					break;
					default :Key_val=0;
					break;
				}
			}
		}
		if(Key_val!=0)
		{
			t=0;
		}
		return Key_val;
	}
	else if(((GPIOC->IDR&0x30)|(GPIOG->IDR&0xC0))==0xF0)
	{
		t=1;
	}
	return 0;
	
}

void gpio_init_key4(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	 
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_GPIOG, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//����ģʽ
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOG,&GPIO_InitStructure);//��ʼ��	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//����ģʽ
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOC,&GPIO_InitStructure);//��ʼ��
}




int yanzheng(int x) 
{
    int a, b, c, d;
		int input_index = 0;
    int key44, input_sequence[4]; // �洢�û����������
    a = x / 1000;
    b = (x % 1000) / 100;
    c = (x % 100) / 10;
    d = x % 10;

    
    while (input_index < 4) 
		{
        key44 = key_init_44(); // ���û������ȡ����
        if (key44 >= 1 && key44 <= 9) 
				{
            input_sequence[input_index++] = key44;
        }else if(key44==16)
				{
					input_sequence[input_index++] = 0;
				}
				
    }

    // ������������Ƿ�������������ƥ��
    if (input_sequence[0] == a && input_sequence[1] == b &&
        input_sequence[2] == c && input_sequence[3] == d) 
		{
            return 1; // ��֤�ɹ�
    }
    return 0; // ��֤ʧ��
}




