#include "SG90.h"

unsigned int key=0,actual_pwm=100;
u32 part=0,time=0;

void SG90(u32 expect_pwm,u32 s)
{
    if(expect_pwm>actual_pwm)
        time=1000000*s*5/(expect_pwm-actual_pwm);//΢�뼶���
    if(expect_pwm<actual_pwm)
        time=1000000*s*5/(actual_pwm-expect_pwm);//΢�뼶���
    if(expect_pwm!=actual_pwm)
    {
        if(expect_pwm>actual_pwm)
        {
            while(1)
            {
                actual_pwm=actual_pwm+5;//һ��
                TIM_SetCompare1(TIM14,actual_pwm);
                part++;
                delay_us(time);
                if(expect_pwm==actual_pwm)
                {
                    part=0;
                    break;
                }
            }
        }
        if(expect_pwm<actual_pwm)
        {
            while(1)
            {
                actual_pwm=actual_pwm-5;
                TIM_SetCompare1(TIM14,actual_pwm);
                part++;
                delay_us(time);
                if(expect_pwm==actual_pwm)
                {
                    part=0;
                    break;
                }
            }
        }
    }
}


