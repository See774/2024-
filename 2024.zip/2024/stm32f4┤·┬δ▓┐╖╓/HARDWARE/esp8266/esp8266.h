#ifndef _ESP8266_H_
#define _ESP8266_H_



#define ESP8266RST_PORT GPIO_Pin_5
#define ESP8266RST_GPIO GPIOA
#define ESP8266RST_SCK RCC_AHB1Periph_GPIOA

#define REV_OK		0	//������ɱ�־
#define REV_WAIT	1	//����δ��ɱ�־
// esp8266 ʹ�õ��Ǵ�����
//����ʹ��sendstring#define esp8266_printf u3_printf  
#define esp8266_RX_STA USART3_RX_STA
#define esp8266_RX_BUF USART3_RX_BUF
#define esp8266_uart  USART3
void ESP8266_Init(void);

void ESP8266_Clear(void);

void ESP8266_SendData(unsigned char *data, unsigned short len);

unsigned char *ESP8266_GetIPD(unsigned short timeOut);

#endif


