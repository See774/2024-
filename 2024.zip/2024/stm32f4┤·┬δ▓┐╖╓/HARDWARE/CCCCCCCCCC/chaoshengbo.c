#include "stm32f4xx.h"
#include "delay.h"
#include "chaoshengbo.h"
#include <stdlib.h>
u16 TIM2_Flag;
u16 get_Distance()
{
  int distance = 0;
  u16 TIM = 0;
  TIM_Cmd(TIM2, ENABLE);           
  
  GPIO_SetBits(GPIOB, GPIO_Pin_9);  
  delay_us(30);
  GPIO_ResetBits(GPIOB, GPIO_Pin_9);
 
  while((!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))&&TIM2_Flag==0);  
  TIM2->CNT = 0;              
  while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8)&&TIM2_Flag==0);    
  TIM_Cmd(TIM2, DISABLE);    
  
  if(TIM2_Flag==1)
    TIM2_Flag = 0;
  
  TIM = TIM_GetCounter(TIM2);
  distance = TIM*0.85;
  return distance;
}
void TIM2_IRQHandler(void)
{
  if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
  {
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    TIM2_Flag=1;
  }
}

void GPIO_Configuration()
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  /*echo*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  /*trig*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
 
}
 
void TIM2_Configuration(u16 arr, u16 psc)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructrue;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  TIM_DeInit(TIM2);
  
  TIM_TimeBaseStructrue.TIM_Period = arr;                   
  TIM_TimeBaseStructrue.TIM_Prescaler = psc;                
  TIM_TimeBaseStructrue.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructrue.TIM_CounterMode = TIM_CounterMode_Up;
  
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructrue);
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
  
  NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn;             
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x00; 
  NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x01;       
  NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
  
  NVIC_Init(&NVIC_InitStructure);                           
  
  TIM_Cmd(TIM2, DISABLE); 
}
#define MAX_ERROR 50 // ��������ֵ
#define MAX_DISTANCE 2300 // ������������ֵ
#define MEASUREMENT_COUNT 5 // ��������
int round_int(double value) 
{
    return (int)(value >= 0 ? value + 0.5 : value - 0.5);
}

// ����ƽ������ĺ���
int average_distance_with_error_check() 
{
    int sum = 0;
    int valid_count = 0;
    int previous_distance = get_Distance();
		int	 i;
    delay_ms(50); // ��������ĳ�����ʱ

    // ѭ��������β���
    for (i = 0; i < MEASUREMENT_COUNT; ++i) 
		{
        int current_distance = get_Distance();
        int error = abs(current_distance - previous_distance); // �������

        // �ж�����Ƿ�ϴ�����ֵ�Ƿ񳬳��˺�����Χ
        if (error <= MAX_ERROR && current_distance <= MAX_DISTANCE) 
				{
            // ���������Ч�����ۼӾ���ֵ
            sum += current_distance;
            valid_count++;
        }

        previous_distance = current_distance;
        delay_ms(50); // ����������֮�������ʱ
    }

    // �������Ч���������㲢����ƽ��ֵ�����򷵻�0
    return (valid_count > 0) ? round_int((double)sum / valid_count) : 0;
}
