#ifndef __SG90_H
#define __SG90_H 			   
#include <sys.h>	  
#include "pwm.h"
#include "delay.h"

void SG90(u32 expect_pwm,u32 s);

#endif



