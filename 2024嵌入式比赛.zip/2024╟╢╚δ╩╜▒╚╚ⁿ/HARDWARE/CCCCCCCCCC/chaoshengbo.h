#ifndef __chaoshengbo_H
 
#define __chaoshengbo_H
#include "sys.h"
void GPIO_Configuration(void);
void TIM2_Configuration(u16 arr,u16 psc);
u16 get_Distance(void);
void TIM2_IRQHandler(void);
int round_int(double value);
int average_distance_with_error_check(void);
#endif

