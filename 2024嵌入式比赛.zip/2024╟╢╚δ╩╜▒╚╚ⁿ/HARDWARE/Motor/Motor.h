#ifndef __MOTOR_H 
#define __MOTOR_H

#include "sys.h" //LED�˿ڶ��� 
//A�߼�����
#define IN0 PFout(3) 
#define IN1 PFout(2)

#define ENABLE_A PFout(8)//Aʹ�ܶ�

//B�߼�����
#define IN2 PFout(1) 
#define IN3 PFout(0)

#define ENABLE_B PFout(7)//Bʹ�ܶ� 

void MOTOR_Init(void);//��ʼ�� 
//void qianjin(void);
//void stop(void);
//void jiansu(void);
//void zuozhuan(void);
//void youzhuan(void);
double get_CurrentAngle(void);
void ControlLoop(void);
//void Controlez(void);
#endif 
